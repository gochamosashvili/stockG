// Recovery Terminal PWA runtime.
// Provides the small `dash` API the dashboard code expects (loaders, calculations,
// data, parameters) and fetches live prices from your Google Apps Script web app.
(function () {
  'use strict';

  var DEFAULTS = {
    mine: true, sector: null, sub: null, q: null, pick: null,
    dd_min: 30, dd_max: null, up_min: null, up_max: 50,
    share_max: 25, weeks_min: 8, health: 'ok', hist_range: 'Prices!A4:O4'
  };
  var PRICES_RANGE = 'Prices!A1:N521';
  var REFRESH_MS = 10 * 60 * 1000;          // auto refresh while the app is open
  var STALE_MS = 5 * 60 * 1000;             // refresh on reopen if older than this
  var LS_PARAMS = 'rt.params', LS_URL = 'rt.apiUrl', LS_CACHE = 'rt.cache.';

  // ---------- small storage helpers (storage can be unavailable) ----------
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } }

  function apiUrl() {
    var fromCfg = (window.STOCK_CONFIG && window.STOCK_CONFIG.API_URL) || '';
    return (fromCfg || lsGet(LS_URL) || '').trim();
  }

  var P = Object.assign({}, DEFAULTS);
  try { Object.assign(P, JSON.parse(lsGet(LS_PARAMS) || '{}')); } catch (e) { /* ignore */ }

  var loaders = {}, calcs = [], subs = [], D = {}, meta = { prices: null };
  var FILES = { sp500: 'data/sp500.json', watchlist: 'data/watchlist.json', fundamentals: 'data/fundamentals.json' };

  // ---------- notify (coalesced) ----------
  var pending = false;
  function notify() {
    if (pending) return;
    pending = true;
    setTimeout(function () {
      pending = false;
      recompute();
      subs.forEach(function (f) { try { f(); } catch (e) { console.error(e); } });
      status();
    }, 0);
  }

  // ---------- calculations ----------
  function recompute() {
    calcs.forEach(function (c) {
      var ins = c.inputs.map(function (id) { return D[id] || { status: 'loading' }; });
      if (ins.some(function (x) { return x.status === 'error'; })) { D[c.id] = { status: 'error', data: [] }; return; }
      if (!ins.every(function (x) { return x.status === 'ok'; })) { D[c.id] = { status: 'loading', data: [] }; return; }
      var key = ins.map(function (x) { return x.rev; }).join('|');
      if (D[c.id] && D[c.id].key === key) return;
      try {
        var out = c.fn.apply(null, ins.map(function (x) { return x.data; }));
        D[c.id] = { status: 'ok', data: out, key: key, rev: key + '>' + c.id };
      } catch (e) {
        console.error('calc ' + c.id, e);
        D[c.id] = { status: 'error', data: [], key: key };
      }
    });
  }
  var revN = 0;
  function setData(id, obj) { obj.rev = ++revN; D[id] = obj; notify(); }

  // ---------- fetching ----------
  function fetchSheet(range) {
    var url = apiUrl();
    if (!url) return Promise.reject(new Error('NO_URL'));
    var u = url + (url.indexOf('?') >= 0 ? '&' : '?') + 'range=' + encodeURIComponent(range) + '&t=' + Date.now();
    return fetch(u, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }).then(function (text) {
      var j = JSON.parse(text);
      if (j && j.error) throw new Error(j.error);
      return { text: text, json: j };
    });
  }

  function loadFile(id) {
    fetch(FILES[id]).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (rows) { setData(id, { status: 'ok', data: rows }); })
      .catch(function (e) { console.error(id, e); setData(id, { status: 'error', data: [] }); });
  }

  function useAnswer(id, json) {
    var res = loaders[id].fn({ answer: json });
    if (id === 'prices') return { status: 'ok', data: res.rows, columns: res.columns };
    return { status: 'ok', data: res.data, meta: res.meta || [] };
  }

  var loadingPrices = false, lastError = null;
  function loadPrices(force) {
    if (loadingPrices || !loaders.prices) return;
    var cached = lsGet(LS_CACHE + 'prices');
    if (!D.prices && cached) {
      try {
        var c = JSON.parse(cached);
        meta.prices = { at: c.at, offline: true };
        setData('prices', useAnswer('prices', c.json));
      } catch (e) { lsDel(LS_CACHE + 'prices'); }
    }
    if (!force && meta.prices && !meta.prices.offline && Date.now() - meta.prices.at < STALE_MS) return;
    loadingPrices = true; status();
    fetchSheet(PRICES_RANGE).then(function (r) {
      var at = Date.now();
      lsSet(LS_CACHE + 'prices', JSON.stringify({ at: at, json: r.json }));
      meta.prices = { at: at, offline: false };
      lastError = null;
      setData('prices', useAnswer('prices', r.json));
      loadHistory();
    }).catch(function (e) {
      lastError = e.message === 'NO_URL' ? 'NO_URL' : 'OFFLINE';
      if (meta.prices) meta.prices.offline = true;
      if (!D.prices) setData('prices', { status: 'error', data: [] });
    }).then(function () { loadingPrices = false; status(); });
  }

  var histToken = 0;
  function loadHistory() {
    if (!loaders.history) return;
    var range = P.hist_range;
    var my = ++histToken;
    var key = LS_CACHE + 'h.' + range;
    var cached = lsGet(key);
    if (cached) {
      try { setData('history', useAnswer('history', JSON.parse(cached))); } catch (e) { lsDel(key); }
    } else {
      setData('history', { status: 'loading', data: [], meta: [] });
    }
    fetchSheet(range).then(function (r) {
      if (my !== histToken) return;
      saveHistory(key, r.json);
      setData('history', useAnswer('history', r.json));
    }).catch(function () {
      if (my !== histToken) return;
      if (!cached) setData('history', { status: 'error', data: [], meta: [] });
    });
  }
  // keep at most 12 company histories on the device
  function saveHistory(key, json) {
    var list = [];
    try { list = JSON.parse(lsGet(LS_CACHE + 'h.list') || '[]'); } catch (e) { list = []; }
    list = list.filter(function (k) { return k !== key; });
    list.push(key);
    while (list.length > 12) lsDel(list.shift());
    lsSet(key, JSON.stringify(json));
    lsSet(LS_CACHE + 'h.list', JSON.stringify(list));
  }

  // ---------- status line + setup box ----------
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function status() {
    var src = document.querySelector('.rt-src');
    if (!src) return;
    var el = document.getElementById('rt-status');
    if (!el) {
      el = document.createElement('div');
      el.id = 'rt-status';
      el.className = 'rt-status';
      var btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'rt-refresh'; btn.textContent = '⟳ განახლება';
      btn.addEventListener('click', function () { loadPrices(true); });
      var txt = document.createElement('span'); txt.className = 'rt-status-t';
      el.append(txt, btn);
      src.append(el);
    }
    var t = el.querySelector('.rt-status-t');
    var m = meta.prices;
    var s = loadingPrices ? 'იტვირთება…' : '';
    if (!s && m) { var d = new Date(m.at); s = 'განახლდა ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + (m.offline ? ' · ოფლაინ' : ''); }
    if (!s && lastError === 'OFFLINE') s = 'კავშირი არ არის';
    t.textContent = s;
    setupBox();
  }

  function setupBox() {
    var need = !apiUrl();
    var box = document.getElementById('rt-setup');
    if (!need) { if (box) box.remove(); return; }
    if (box) return;
    var host = document.querySelector('.rt');
    if (!host) return;
    box = document.createElement('div');
    box.id = 'rt-setup'; box.className = 'rt-card rt-setup';
    box.innerHTML = '<h2 class="rt-h">პირველი გაშვება: მონაცემების მისამართი</h2>' +
      '<p class="rt-note">ჩასვი Google Apps Script-ის Web app მისამართი (მთავრდება /exec-ით). ერთხელ საკმარისია: ტელეფონი დაიმახსოვრებს.</p>' +
      '<div class="rt-setup-row"><input class="rt-search rt-setup-in" type="url" placeholder="https://script.google.com/macros/s/…/exec" aria-label="Apps Script მისამართი">' +
      '<button type="button" class="rt-btn rt-setup-ok">შენახვა</button></div><p class="rt-note rt-setup-msg"></p>';
    host.insertBefore(box, host.children[1] || null);
    box.querySelector('.rt-setup-ok').addEventListener('click', function () {
      var v = box.querySelector('.rt-setup-in').value.trim();
      var msg = box.querySelector('.rt-setup-msg');
      if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(v)) { msg.textContent = 'მისამართი ასე უნდა გამოიყურებოდეს: https://script.google.com/macros/s/…/exec'; return; }
      lsSet(LS_URL, v);
      box.remove();
      loadPrices(true);
    });
  }

  // ---------- public API ----------
  window.dash = {
    loader: function (id, def) { loaders[id] = def; },
    calc: function (id, def) { calcs.push({ id: id, inputs: def.inputs, fn: def.fn }); },
    data: function (id) {
      var d = D[id];
      if (!d) return { status: 'loading', data: [], meta: [] };
      return { status: d.status, data: d.data || [], meta: d.meta || [] };
    },
    params: function () { return Object.assign({}, P); },
    setParams: function (o) {
      var prevHist = P.hist_range;
      Object.keys(o).forEach(function (k) { P[k] = o[k]; });
      lsSet(LS_PARAMS, JSON.stringify(P));
      if (P.hist_range !== prevHist && /^Prices!A\d+:O\d+$/.test(P.hist_range || '')) loadHistory();
      notify();
    },
    resetParams: function () { window.dash.setParams(Object.assign({}, DEFAULTS, { hist_range: P.hist_range })); },
    setLink: function (page) { try { history.replaceState(null, '', page === 'company' ? '#company' : location.pathname + location.search); } catch (e) { /* ignore */ } },
    onData: function (f) {
      subs.push(f);
      if (subs.length === 1) start();
      notify();
    }
  };

  var started = false;
  function start() {
    if (started) return;
    started = true;
    Object.keys(FILES).forEach(loadFile);
    loadPrices(false);
    if (D.prices && D.prices.status === 'ok') loadHistory();
    setInterval(function () { if (document.visibilityState === 'visible') loadPrices(true); }, REFRESH_MS);
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') loadPrices(false); });
    window.addEventListener('online', function () { loadPrices(true); });
    status();
  }
})();
