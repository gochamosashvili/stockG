// ჩასვი შენი Google Apps Script Web app-ის მისამართი (მთავრდება /exec-ით).
// თუ ცარიელს დატოვებ, აპი პირველ გაშვებაზე თავად მოგთხოვს მისამართს.
window.STOCK_CONFIG = {
  API_URL: ''
};
