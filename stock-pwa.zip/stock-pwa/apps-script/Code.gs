/**
 * Recovery Terminal: data endpoint for the PWA.
 * Returns cells of the "Prices" tab as JSON: {"range": "...", "values": [[...], ...]}.
 * Only ranges of the Prices tab (columns A–O, rows 1–999) can be read.
 */
const SPREADSHEET_ID = '1X8IkpTcwoSuArteakh-gV4prm7xfIYPdgeTqmvg5R5g';

function doGet(e) {
  const range = String((e && e.parameter && e.parameter.range) || 'Prices!A1:N521');
  if (!/^Prices!A[1-9]\d{0,2}:[A-O][1-9]\d{0,2}$/.test(range)) {
    return json_({ error: 'Range not allowed: ' + range });
  }
  try {
    const values = SpreadsheetApp.openById(SPREADSHEET_ID).getRange(range).getDisplayValues();
    return json_({ range: range, values: values });
  } catch (err) {
    return json_({ error: String(err) });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Run once from the editor to grant access and check the output. */
function test() {
  const out = doGet({ parameter: { range: 'Prices!A1:N3' } });
  Logger.log(out.getContent());
}
